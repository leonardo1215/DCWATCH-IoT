#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

#include <DHTesp.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <ESP32Servo.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <LiquidCrystal_I2C.h>

// ================= WIFI / MQTT =================
// No Wokwi, use exatamente este Wi-Fi:
const char* WIFI_SSID = "Wokwi-GUEST";
const char* WIFI_PASS = "";

// Broker MQTT público para teste
const char* MQTT_SERVER = "broker.hivemq.com";
const int MQTT_PORT = 1883;

const char* TOPIC_TELEMETRY = "dcwatch/rack01/telemetry";
const char* TOPIC_ALERT = "dcwatch/rack01/alert";
const char* TOPIC_STATUS = "dcwatch/rack01/status";

WiFiClient espClient;
PubSubClient mqtt(espClient);

String lastStatus = "";

// ================= PINOS =================
#define PIN_DHT          15
#define PIN_DS18B20      16
#define PIN_PIR          27
#define PIN_LDR          32
#define PIN_SMOKE        34
#define PIN_POWER        35
#define PIN_BTN_DOOR     4
#define PIN_BTN_ENERGY   18

#define PIN_BUZZER       5
#define PIN_SERVO        19

#define LED_BLUE         13
#define LED_RED          14
#define LED_YELLOW       26
#define LED_GREEN        25

// ================= LIMITES =================
#define TEMP_AMB_ATTENTION   28.0
#define TEMP_AMB_CRITICAL    32.0
#define TEMP_RACK_ATTENTION  32.0
#define TEMP_RACK_CRITICAL   38.0
#define HUMIDITY_ATTENTION   65.0
#define SMOKE_CRITICAL       70
#define POWER_ATTENTION      75

// ================= OBJETOS =================
DHTesp dht;
OneWire oneWire(PIN_DS18B20);
DallasTemperature ds18b20(&oneWire);
Servo servoFan;

Adafruit_SSD1306 oled(128, 64, &Wire, -1);
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ================= VARIAVEIS =================
unsigned long lastRead = 0;
const unsigned long readInterval = 2000;

unsigned long lastMqttTry = 0;
const unsigned long mqttRetryInterval = 5000;

String lastLcdLine1 = "";
String lastLcdLine2 = "";

struct DataCenterData {
  float tempAmb;
  float humidity;
  float tempRack;
  int smoke;
  int power;
  int light;
  bool motion;
  bool doorOpen;
  bool energyFail;
  String status;
  bool fanOn;
  bool buzzerOn;
  int servoAngle;
};

// ================= PROTOTIPOS =================
void connectWiFi();
void connectMQTT();
void publishTelemetry(DataCenterData data);
void publishAlertIfNeeded(DataCenterData data);
String createAlertMessage(DataCenterData data);

void showBootScreen();
DataCenterData readSensors();
void processStatus(DataCenterData &data);
void updateActuators(DataCenterData data);
void updateDisplays(DataCenterData data);
void updateLCD(DataCenterData data);
void updateOLED(DataCenterData data);
String fitLine(String text);
void printSerial(DataCenterData data);

// ================= SETUP =================
void setup() {
  Serial.begin(115200);
  delay(500);

  dht.setup(PIN_DHT, DHTesp::DHT22);
  ds18b20.begin();

  pinMode(PIN_PIR, INPUT);
  pinMode(PIN_BTN_DOOR, INPUT_PULLUP);
  pinMode(PIN_BTN_ENERGY, INPUT_PULLUP);

  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_YELLOW, OUTPUT);
  pinMode(LED_RED, OUTPUT);
  pinMode(LED_BLUE, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);

  servoFan.attach(PIN_SERVO);

  Wire.begin(21, 22);

  if (!oled.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("Falha ao iniciar OLED");
  }
  oled.clearDisplay();
  oled.setTextColor(SSD1306_WHITE);

  lcd.init();
  lcd.backlight();

  showBootScreen();

  mqtt.setServer(MQTT_SERVER, MQTT_PORT);
  mqtt.setBufferSize(512);
  mqtt.setKeepAlive(60);

  connectWiFi();
}

// ================= LOOP =================
void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    if (millis() - lastMqttTry > mqttRetryInterval) {
      lastMqttTry = millis();
      connectWiFi();
    }
  } else if (!mqtt.connected()) {
    if (millis() - lastMqttTry > mqttRetryInterval) {
      lastMqttTry = millis();
      connectMQTT();
    }
  } else {
    mqtt.loop();
  }

  if (millis() - lastRead >= readInterval) {
    lastRead = millis();

    DataCenterData data = readSensors();
    processStatus(data);
    updateActuators(data);
    updateDisplays(data);
    printSerial(data);

    if (WiFi.status() == WL_CONNECTED && mqtt.connected()) {
      publishTelemetry(data);
      publishAlertIfNeeded(data);
    } else {
      Serial.println("MQTT offline: telemetria nao enviada.");
    }
  }
}

// ================= WIFI / MQTT =================

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) {
    return;
  }

  Serial.println();
  Serial.println("===== WIFI =====");
  Serial.print("Conectando em: ");
  Serial.println(WIFI_SSID);

  WiFi.disconnect(true);
  delay(500);

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);

  // IMPORTANTE PARA WOKWI:
  // O Wi-Fi virtual Wokwi-GUEST usa canal 6.
  WiFi.begin(WIFI_SSID, WIFI_PASS, 6);

  unsigned long startAttempt = millis();

  while (WiFi.status() != WL_CONNECTED && millis() - startAttempt < 20000) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("WiFi conectado!");
    Serial.print("IP: ");
    Serial.println(WiFi.localIP());
    Serial.print("RSSI: ");
    Serial.println(WiFi.RSSI());
  } else {
    Serial.print("Falha no WiFi. Codigo status: ");
    Serial.println(WiFi.status());
    Serial.println("No Wokwi, confirme SSID Wokwi-GUEST, senha vazia e simulação com internet ativa.");
  }
}

void connectMQTT() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("MQTT nao tentou conectar: WiFi offline.");
    return;
  }

  if (mqtt.connected()) {
    return;
  }

  Serial.println();
  Serial.println("===== MQTT =====");
  Serial.print("Broker: ");
  Serial.print(MQTT_SERVER);
  Serial.print(":");
  Serial.println(MQTT_PORT);

  String clientId = "dcwatch-rack01-";
  clientId += String((uint32_t)ESP.getEfuseMac(), HEX);

  Serial.print("Cliente MQTT: ");
  Serial.println(clientId);

  if (mqtt.connect(clientId.c_str())) {
    Serial.println("MQTT conectado!");
    mqtt.publish(TOPIC_STATUS, "ESP32 online", true);
  } else {
    Serial.print("Falha MQTT. Codigo rc=");
    Serial.println(mqtt.state());
  }
}

void publishTelemetry(DataCenterData data) {
  StaticJsonDocument<512> doc;

  doc["rack"] = "rack01";
  doc["status"] = data.status;
  doc["tempAmb"] = data.tempAmb;
  doc["humidity"] = data.humidity;
  doc["tempRack"] = data.tempRack;
  doc["smoke"] = data.smoke;
  doc["power"] = data.power;
  doc["light"] = data.light;
  doc["motion"] = data.motion;
  doc["doorOpen"] = data.doorOpen;
  doc["energyFail"] = data.energyFail;
  doc["fanOn"] = data.fanOn;
  doc["servoAngle"] = data.servoAngle;
  doc["wifiRssi"] = WiFi.RSSI();

  char payload[512];
  serializeJson(doc, payload);

  bool ok = mqtt.publish(TOPIC_TELEMETRY, payload);

  Serial.print("MQTT Telemetry: ");
  Serial.println(ok ? "ENVIADO" : "FALHOU");
  Serial.println(payload);
}

void publishAlertIfNeeded(DataCenterData data) {
  if (data.status != lastStatus) {
    StaticJsonDocument<256> doc;

    doc["rack"] = "rack01";
    doc["oldStatus"] = lastStatus;
    doc["newStatus"] = data.status;
    doc["message"] = createAlertMessage(data);

    char payload[256];
    serializeJson(doc, payload);

    bool ok = mqtt.publish(TOPIC_ALERT, payload);

    lastStatus = data.status;

    Serial.print("MQTT Alert: ");
    Serial.println(ok ? "ENVIADO" : "FALHOU");
    Serial.println(payload);
  }
}

String createAlertMessage(DataCenterData data) {
  if (data.status == "NORMAL") {
    return "Sistema normalizado";
  }

  if (data.status == "ATENCAO") {
    return "Atencao: temperatura, umidade, consumo ou porta em estado de alerta";
  }

  if (data.status == "CRITICO") {
    return "Critico: risco de superaquecimento, fumaca, falha de energia ou erro de sensor";
  }

  return "Status desconhecido";
}

// ================= FUNCOES DO SISTEMA =================

void showBootScreen() {
  lcd.setCursor(0, 0);
  lcd.print("DC Watch IoT");
  lcd.setCursor(0, 1);
  lcd.print("Iniciando...");

  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setCursor(0, 0);
  oled.print("DC Watch IoT");
  oled.setCursor(0, 16);
  oled.print("Monitoramento");
  oled.setCursor(0, 28);
  oled.print("Data Center");
  oled.display();

  delay(1500);
}

DataCenterData readSensors() {
  DataCenterData data;

  TempAndHumidity dhtData = dht.getTempAndHumidity();

  if (isnan(dhtData.temperature) || isnan(dhtData.humidity)) {
    data.tempAmb = -99;
    data.humidity = -1;
  } else {
    data.tempAmb = dhtData.temperature;
    data.humidity = dhtData.humidity;
  }

  ds18b20.requestTemperatures();
  data.tempRack = ds18b20.getTempCByIndex(0);

  data.smoke = map(analogRead(PIN_SMOKE), 0, 4095, 0, 100);
  data.power = map(analogRead(PIN_POWER), 0, 4095, 0, 100);
  data.light = map(analogRead(PIN_LDR), 0, 4095, 0, 100);

  data.motion = digitalRead(PIN_PIR) == HIGH;
  data.doorOpen = digitalRead(PIN_BTN_DOOR) == LOW;
  data.energyFail = digitalRead(PIN_BTN_ENERGY) == LOW;

  data.status = "NORMAL";
  data.fanOn = false;
  data.buzzerOn = false;
  data.servoAngle = 0;

  return data;
}

void processStatus(DataCenterData &data) {
  bool dhtError = data.tempAmb == -99 || data.humidity == -1;
  bool dsError = data.tempRack <= -100 || data.tempRack >= 85;

  if (
    dhtError ||
    dsError ||
    data.tempAmb >= TEMP_AMB_CRITICAL ||
    data.tempRack >= TEMP_RACK_CRITICAL ||
    data.smoke >= SMOKE_CRITICAL ||
    data.energyFail
  ) {
    data.status = "CRITICO";
    data.fanOn = true;
    data.buzzerOn = true;
    data.servoAngle = 90;
  }
  else if (
    data.tempAmb >= TEMP_AMB_ATTENTION ||
    data.tempRack >= TEMP_RACK_ATTENTION ||
    data.humidity >= HUMIDITY_ATTENTION ||
    data.power >= POWER_ATTENTION ||
    data.doorOpen
  ) {
    data.status = "ATENCAO";
    data.fanOn = true;
    data.buzzerOn = false;
    data.servoAngle = 45;
  }
}

void updateActuators(DataCenterData data) {
  digitalWrite(LED_GREEN, data.status == "NORMAL");
  digitalWrite(LED_YELLOW, data.status == "ATENCAO");
  digitalWrite(LED_RED, data.status == "CRITICO");
  digitalWrite(LED_BLUE, data.fanOn);

  if (data.buzzerOn) {
    tone(PIN_BUZZER, 1200);
  } else {
    noTone(PIN_BUZZER);
  }

  servoFan.write(data.servoAngle);
}

void updateDisplays(DataCenterData data) {
  updateLCD(data);
  updateOLED(data);
}

void updateLCD(DataCenterData data) {
  String line1 = "Status:" + data.status;
  String line2 = "T:" + String(data.tempAmb, 1) + " R:" + String(data.tempRack, 1);

  line1 = fitLine(line1);
  line2 = fitLine(line2);

  if (line1 != lastLcdLine1 || line2 != lastLcdLine2) {
    lcd.setCursor(0, 0);
    lcd.print(line1);
    lcd.setCursor(0, 1);
    lcd.print(line2);

    lastLcdLine1 = line1;
    lastLcdLine2 = line2;
  }
}

String fitLine(String text) {
  while (text.length() < 16) text += " ";
  if (text.length() > 16) text = text.substring(0, 16);
  return text;
}

void updateOLED(DataCenterData data) {
  oled.clearDisplay();
  oled.setTextSize(1);

  oled.setCursor(0, 0);
  oled.print("DC Watch IoT");

  oled.setCursor(0, 10);
  oled.print("Status: ");
  oled.print(data.status);

  oled.setCursor(0, 22);
  oled.print("Amb: ");
  oled.print(data.tempAmb, 1);
  oled.print("C ");
  oled.print(data.humidity, 0);
  oled.print("%");

  oled.setCursor(0, 34);
  oled.print("Rack: ");
  oled.print(data.tempRack, 1);
  oled.print("C");

  oled.setCursor(0, 46);
  oled.print("Smoke:");
  oled.print(data.smoke);
  oled.print("% Pwr:");
  oled.print(data.power);
  oled.print("%");

  oled.setCursor(0, 56);
  oled.print("D:");
  oled.print(data.doorOpen ? "OPEN " : "OK ");
  oled.print("E:");
  oled.print(data.energyFail ? "FAIL " : "OK ");
  oled.print("M:");
  oled.print(data.motion ? "Y" : "N");

  oled.display();
}

void printSerial(DataCenterData data) {
  Serial.println("===== DC Watch IoT =====");
  Serial.print("Status: "); Serial.println(data.status);
  Serial.print("Temp Ambiente: "); Serial.print(data.tempAmb); Serial.println(" C");
  Serial.print("Umidade: "); Serial.print(data.humidity); Serial.println(" %");
  Serial.print("Temp Rack: "); Serial.print(data.tempRack); Serial.println(" C");
  Serial.print("Fumaca: "); Serial.print(data.smoke); Serial.println(" %");
  Serial.print("Consumo: "); Serial.print(data.power); Serial.println(" %");
  Serial.print("Luz: "); Serial.print(data.light); Serial.println(" %");
  Serial.print("Movimento: "); Serial.println(data.motion ? "SIM" : "NAO");
  Serial.print("Porta: "); Serial.println(data.doorOpen ? "ABERTA" : "FECHADA");
  Serial.print("Energia: "); Serial.println(data.energyFail ? "FALHA" : "OK");
  Serial.print("Ventilacao: "); Serial.println(data.fanOn ? "ON" : "OFF");
  Serial.println();
}
